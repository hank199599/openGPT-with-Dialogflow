# openGPT-with-Dialogflow
an project to intergrate OpenChat GPT to Dialogflow

## Reference
[beta.openai.com](https://beta.openai.com/docs/api-reference/completions/create?lang=node.js)

# 如何建立自己的版本？
1. 下載這個專案到自己的本機
2. 安裝所需的模組
```
npm i
```
3. 

# 如何進行部署？
  1. 建立 [Google Cloud Platform](https://cloud.google.com/free?hl=zh-tw)專案
  2. 建立專案
  3. 


```cmd
 firebase deploy --only functions:chatGPT
 ```